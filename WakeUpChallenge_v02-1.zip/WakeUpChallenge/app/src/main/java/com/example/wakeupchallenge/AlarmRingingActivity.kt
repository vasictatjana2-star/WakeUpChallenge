package com.example.wakeupchallenge

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class AlarmRingingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val a = Random.nextInt(2, 20)
        val b = Random.nextInt(2, 20)
        setContent {
            MaterialTheme {
                var answer by remember { mutableStateOf("") }
                var message by remember { mutableStateOf("Solve to dismiss the alarm.") }
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("WAKE UP!", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.height(16.dp))
                        Text("$a + $b = ?", style = MaterialTheme.typography.headlineMedium)
                        OutlinedTextField(
                            value = answer, onValueChange = { answer = it.filter(Char::isDigit) },
                            label = { Text("Answer") }
                        )
                        Button(onClick = {
                            if (answer.toIntOrNull() == a + b) {
                                stopService(Intent(this@AlarmRingingActivity, AlarmSoundService::class.java))
                                finish()
                            } else message = "Not quite. Try again!"
                        }) { Text("Dismiss alarm") }
                        Text(message)
                        TextButton(onClick = {
                            // Basic snooze: stop sound and schedule a 5-minute alarm.
                            stopService(Intent(this@AlarmRingingActivity, AlarmSoundService::class.java))
                            AlarmScheduler.scheduleAt(this@AlarmRingingActivity, System.currentTimeMillis() + 5 * 60_000)
                            finish()
                        }) { Text("Snooze 5 minutes") }
                    }
                }
            }
        }
    }
}
