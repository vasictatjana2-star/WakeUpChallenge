package com.example.wakeupchallenge

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = AlarmStore.read(this)
        setContent {
            MaterialTheme {
                var hour by remember { mutableIntStateOf(saved.first) }
                var minute by remember { mutableIntStateOf(saved.second) }
                var enabled by remember { mutableStateOf(saved.third) }
                var status by remember { mutableStateOf(if (enabled) "Alarm is enabled" else "Alarm is off") }

                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("WakeUp Challenge", style = MaterialTheme.typography.headlineMedium)
                        Text("Solve a quick math problem to dismiss your alarm.")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            NumberPicker("Hour", hour, 0..23) { hour = it }
                            Spacer(Modifier.width(16.dp))
                            NumberPicker("Minute", minute, 0..59) { minute = it }
                        }
                        Button(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val manager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                if (!manager.canScheduleExactAlarms()) {
                                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                                    status = "Allow exact alarms in system settings, then tap Set alarm again."
                                    return@Button
                                }
                            }
                            AlarmStore.save(this@MainActivity, hour, minute, true)
                            AlarmScheduler.schedule(this@MainActivity, hour, minute)
                            enabled = true
                            status = "Alarm set for %02d:%02d".format(hour, minute)
                        }) { Text("Set alarm") }

                        OutlinedButton(onClick = {
                            AlarmScheduler.cancel(this@MainActivity)
                            AlarmStore.save(this@MainActivity, hour, minute, false)
                            enabled = false
                            status = "Alarm is off"
                        }) { Text("Turn alarm off") }

                        Text(status)
                        Text(
                            "Prototype note: please test on your own device. Alarm behavior can " +
                            "vary with Android version and manufacturer battery restrictions.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NumberPicker(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onChange(if (value == range.first) range.last else value - 1) }) {
                Text("−")
            }
            Text(value.toString().padStart(2, '0'), style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { onChange(if (value == range.last) range.first else value + 1) }) {
                Text("+")
            }
        }
    }
}
