package com.example.wakeupchallenge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val (hour, minute, enabled) = AlarmStore.read(context)
        if (enabled) AlarmScheduler.schedule(context, hour, minute)
    }
}
