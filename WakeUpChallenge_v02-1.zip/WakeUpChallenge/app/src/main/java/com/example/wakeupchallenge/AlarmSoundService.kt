package com.example.wakeupchallenge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder

class AlarmSoundService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "wake_alarm_channel"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, makeNotification())
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer.create(this, uri)?.apply {
                isLooping = true
                start()
            }
        } catch (_: Exception) {
            // Device may not have a default alarm tone available.
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Alarm", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "WakeUp Challenge alarm sound" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun makeNotification(): Notification {
        val dismissIntent = PendingIntent.getBroadcast(
            this, 42, Intent(this, AlarmActionReceiver::class.java).setAction("DISMISS"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("WakeUp Challenge")
            .setContentText("Alarm is ringing")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                null, "Stop", dismissIntent
            ).build())
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    override fun onDestroy() {
        player?.runCatching { stop(); release() }
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
