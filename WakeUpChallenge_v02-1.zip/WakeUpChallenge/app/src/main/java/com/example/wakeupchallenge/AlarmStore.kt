package com.example.wakeupchallenge

import android.content.Context
import java.util.Calendar

object AlarmStore {
    private const val PREFS = "wake_alarm_prefs"
    private const val HOUR = "hour"
    private const val MINUTE = "minute"
    private const val ENABLED = "enabled"

    fun save(context: Context, hour: Int, minute: Int, enabled: Boolean = true) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(HOUR, hour).putInt(MINUTE, minute).putBoolean(ENABLED, enabled).apply()
    }

    fun read(context: Context): Triple<Int, Int, Boolean> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Triple(p.getInt(HOUR, 7), p.getInt(MINUTE, 0), p.getBoolean(ENABLED, false))
    }

    fun nextTrigger(hour: Int, minute: Int): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }
}
