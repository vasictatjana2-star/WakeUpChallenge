# WakeUp Challenge — Android starter

A minimal Kotlin + Jetpack Compose starter for an alarm app with a math challenge.

## Open it
1. Extract this ZIP.
2. Open the `WakeUpChallenge` folder in Android Studio.
3. Let Gradle sync.
4. Run on a real Android device or emulator.

## Important
This is an early prototype, not a production-ready alarm. It currently schedules one one-shot alarm and launches a math challenge screen. It does not yet implement a reliable alarm sound/foreground service, boot restore, recurring days, alarm persistence, full permission UX, or AdMob.

Before release, implement and test:
- Foreground service with audio focus and proper alarm channel.
- Notification and exact-alarm permission flows across Android versions.
- Restore alarms after reboot/time changes.
- Save alarms locally; support multiple and recurring alarms.
- AdMob integration with test ad IDs first; never click your own ads.
- Privacy policy, Data safety form, Play Console testing and release requirements.

The package name `com.example.wakeupchallenge` is a placeholder. Choose a permanent unique application ID before publishing.
