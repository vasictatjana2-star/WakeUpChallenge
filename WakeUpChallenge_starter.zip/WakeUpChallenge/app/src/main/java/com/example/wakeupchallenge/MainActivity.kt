package com.example.wakeupchallenge

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var hour by remember { mutableIntStateOf(7) }
                var minute by remember { mutableIntStateOf(0) }
                var status by remember { mutableStateOf("Choose a time for your alarm.") }

                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("WakeUp Challenge", style = MaterialTheme.typography.headlineMedium)
                        Text("Alarm with a quick math challenge", style = MaterialTheme.typography.bodyLarge)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            NumberPicker("Hour", hour, 0..23) { hour = it }
                            Spacer(Modifier.width(16.dp))
                            NumberPicker("Minute", minute, 0..59) { minute = it }
                        }
                        Button(onClick = {
                            scheduleAlarm(hour, minute)
                            status = "Alarm set for %02d:%02d".format(hour, minute)
                        }) { Text("Set alarm") }
                        Text(status)
                        Text(
                            "This starter build is for development. Before publishing, add permission " +
                            "flows, recurring alarms, sound controls, persistence and AdMob."
                        )
                    }
                }
            }
        }
    }

    private fun scheduleAlarm(hour: Int, minute: Int) {
        val manager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !manager.canScheduleExactAlarms()
        ) {
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            return
        }

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }

        val intent = Intent(this, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
    }
}

@Composable
private fun NumberPicker(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onChange(if (value == range.first) range.last else value - 1) }) {
                Text("−")
            }
            Text(value.toString().padStart(2, '0'), style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { onChange(if (value == range.last) range.first else value + 1) }) {
                Text("+")
            }
        }
    }
}
